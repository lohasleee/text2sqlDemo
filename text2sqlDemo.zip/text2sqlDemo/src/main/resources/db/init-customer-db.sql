-- 客户系统库初始化（H2 MySQL 模式 / MySQL 均可执行）
DROP TABLE IF EXISTS t_customer;

CREATE TABLE t_customer (
    id              BIGINT          NOT NULL AUTO_INCREMENT COMMENT '客户主键 ID',
    customer_name   VARCHAR(64)     NOT NULL COMMENT '客户姓名或企业名称',
    phone           VARCHAR(20)     DEFAULT NULL COMMENT '联系电话',
    region          VARCHAR(64)     DEFAULT NULL COMMENT '所属区域（省/市或大区）',
    level           VARCHAR(16)     NOT NULL DEFAULT 'NORMAL' COMMENT '客户等级：NORMAL-普通，SILVER-银卡，GOLD-金卡，VIP-VIP',
    create_time     TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '客户创建/入库时间',
    PRIMARY KEY (id)
) COMMENT='客户信息表（客户系统库）';

INSERT INTO t_customer (customer_name, phone, region, level, create_time) VALUES
    ('张三', '13800138001', '华南/深圳', 'VIP', '2026-01-08 10:00:00'),
    ('李四', '13800138002', '华东/杭州', 'GOLD', '2026-01-15 14:30:00'),
    ('王芳', '13800138003', '华北/北京', 'SILVER', '2026-02-20 09:15:00');
