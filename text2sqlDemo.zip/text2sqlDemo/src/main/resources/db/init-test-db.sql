-- =============================================================================
-- Text2SQL 演示库初始化脚本
-- 数据库：text2sql_demo
-- 说明：创建客户表、订单表并插入测试数据（表与字段均含中文 COMMENT）
-- =============================================================================

CREATE DATABASE IF NOT EXISTS text2sql_demo
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE text2sql_demo;

-- -----------------------------------------------------------------------------
-- 客户表 t_customer
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS t_order;
DROP TABLE IF EXISTS t_customer;

CREATE TABLE t_customer (
    id              BIGINT          NOT NULL AUTO_INCREMENT COMMENT '客户主键 ID，自增',
    customer_code   VARCHAR(32)     NOT NULL COMMENT '客户编码，业务唯一标识',
    customer_name   VARCHAR(64)     NOT NULL COMMENT '客户姓名或企业名称',
    phone           VARCHAR(20)     DEFAULT NULL COMMENT '联系电话',
    email           VARCHAR(128)    DEFAULT NULL COMMENT '电子邮箱',
    gender          TINYINT         DEFAULT NULL COMMENT '性别：0-未知，1-男，2-女',
    province        VARCHAR(32)     DEFAULT NULL COMMENT '所在省份',
    city            VARCHAR(32)     DEFAULT NULL COMMENT '所在城市',
    status          TINYINT         NOT NULL DEFAULT 1 COMMENT '客户状态：0-禁用，1-正常',
    register_time   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
    remark          VARCHAR(255)    DEFAULT NULL COMMENT '备注信息',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录创建时间',
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录最后更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_customer_code (customer_code),
    KEY idx_customer_name (customer_name),
    KEY idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户信息表，存储 C 端或 B 端客户基础资料';

-- -----------------------------------------------------------------------------
-- 订单表 t_order
-- -----------------------------------------------------------------------------
CREATE TABLE t_order (
    id              BIGINT          NOT NULL AUTO_INCREMENT COMMENT '订单主键 ID，自增',
    order_no        VARCHAR(32)     NOT NULL COMMENT '订单编号，业务唯一',
    customer_id     BIGINT          NOT NULL COMMENT '下单客户 ID，关联 t_customer.id',
    order_title     VARCHAR(128)    NOT NULL COMMENT '订单标题或商品摘要',
    order_amount    DECIMAL(12, 2)  NOT NULL DEFAULT 0.00 COMMENT '订单金额（元），含商品与服务费用',
    pay_amount      DECIMAL(12, 2)  DEFAULT NULL COMMENT '实付金额（元），优惠后实际支付',
    order_status    TINYINT         NOT NULL DEFAULT 0 COMMENT '订单状态：0-待支付，1-已支付，2-已发货，3-已完成，4-已取消',
    pay_time        DATETIME        DEFAULT NULL COMMENT '支付完成时间',
    ship_time       DATETIME        DEFAULT NULL COMMENT '发货时间',
    finish_time     DATETIME        DEFAULT NULL COMMENT '订单完成/签收时间',
    cancel_reason   VARCHAR(255)    DEFAULT NULL COMMENT '取消原因（仅取消状态时填写）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '订单创建时间',
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '订单最后更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_order_no (order_no),
    KEY idx_customer_id (customer_id),
    KEY idx_order_status (order_status),
    KEY idx_created_at (created_at),
    CONSTRAINT fk_order_customer FOREIGN KEY (customer_id) REFERENCES t_customer (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表，记录客户下单、支付与履约状态';

-- -----------------------------------------------------------------------------
-- 测试数据：客户
-- -----------------------------------------------------------------------------
INSERT INTO t_customer (customer_code, customer_name, phone, email, gender, province, city, status, register_time, remark)
VALUES
    ('C20260001', '张三', '13800138001', 'zhangsan@example.com', 1, '广东省', '深圳市', 1, '2026-01-10 09:15:00', 'VIP 客户'),
    ('C20260002', '李四', '13800138002', 'lisi@example.com', 1, '浙江省', '杭州市', 1, '2026-01-12 14:30:00', NULL),
    ('C20260003', '王芳', '13800138003', 'wangfang@example.com', 2, '北京市', '北京市', 1, '2026-02-01 11:00:00', '企业采购联系人'),
    ('C20260004', '深圳科创有限公司', '0755-88886666', 'contact@sztech.com', 0, '广东省', '深圳市', 1, '2026-02-15 16:45:00', 'B 端企业客户'),
    ('C20260005', '赵六', '13800138005', NULL, 1, '四川省', '成都市', 0, '2026-03-01 08:20:00', '账号已禁用');

-- -----------------------------------------------------------------------------
-- 测试数据：订单（customer_id 与上面插入顺序对应 1~5）
-- -----------------------------------------------------------------------------
INSERT INTO t_order (order_no, customer_id, order_title, order_amount, pay_amount, order_status, pay_time, ship_time, finish_time, cancel_reason)
VALUES
    ('O20260301001', 1, '笔记本电脑 × 1', 5999.00, 5799.00, 3, '2026-03-01 10:05:00', '2026-03-02 09:00:00', '2026-03-05 18:30:00', NULL),
    ('O20260301002', 1, '无线鼠标 × 2', 198.00, 198.00, 3, '2026-03-01 10:20:00', '2026-03-01 15:00:00', '2026-03-03 12:00:00', NULL),
    ('O20260302001', 2, '机械键盘 × 1', 459.00, 429.00, 2, '2026-03-02 11:30:00', '2026-03-03 08:00:00', NULL, NULL),
    ('O20260305001', 3, '显示器 27 寸 × 3', 4500.00, 4350.00, 1, '2026-03-05 09:00:00', NULL, NULL, NULL),
    ('O20260308001', 4, '年度软件订阅服务', 12800.00, 12800.00, 3, '2026-03-08 14:00:00', NULL, '2026-03-08 14:05:00', NULL),
    ('O20260310001', 2, 'USB-C 扩展坞 × 1', 299.00, NULL, 0, NULL, NULL, NULL, NULL),
    ('O20260312001', 3, '误下单商品', 99.00, NULL, 4, NULL, NULL, NULL, '用户主动取消');
