package com.example.text2sql.web.dto;

import jakarta.validation.constraints.NotBlank;

public record ChatAskRequest(
        @NotBlank(message = "dbName 不能为空") String dbName,
        @NotBlank(message = "question 不能为空") String question,
        String operator) {
}
