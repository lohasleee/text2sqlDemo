package com.example.text2sql.web.support;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.util.StringUtils;

public final class OperatorResolver {

    public static final String HEADER_OPERATOR = "X-Operator-Id";

    private OperatorResolver() {
    }

    public static String resolve(String bodyOperator, HttpServletRequest request) {
        if (StringUtils.hasText(bodyOperator)) {
            return bodyOperator.trim();
        }
        String header = request.getHeader(HEADER_OPERATOR);
        if (StringUtils.hasText(header)) {
            return header.trim();
        }
        Object attr = request.getAttribute(AuditLoggingInterceptor.ATTR_OPERATOR);
        if (attr instanceof String s && StringUtils.hasText(s)) {
            return s.trim();
        }
        return "anonymous";
    }
}
