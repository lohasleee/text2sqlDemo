package com.example.text2sql.web.dto;

public record ChatAskResponse(
        String requestId,
        String dbName,
        String question,
        String sql,
        String reasoning,
        String status,
        boolean securityCheckPassed,
        String message) {
}
