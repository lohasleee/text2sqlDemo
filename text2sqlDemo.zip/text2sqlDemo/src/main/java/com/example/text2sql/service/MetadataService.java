package com.example.text2sql.service;

import com.example.text2sql.metadata.DatabaseSchemaDescription;
import com.example.text2sql.metadata.H2SchemaIntrospector;
import com.example.text2sql.metadata.ColumnSchema;
import com.example.text2sql.metadata.TableSchema;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MetadataService {

    private final DynamicJdbcService dynamicJdbcService;
    private final ObjectMapper objectMapper;

    public MetadataService(DynamicJdbcService dynamicJdbcService) {
        this.dynamicJdbcService = dynamicJdbcService;
        this.objectMapper = new ObjectMapper()
                .enable(SerializationFeature.INDENT_OUTPUT);
    }

    public DatabaseSchemaDescription loadSchema(String dbName) {
        JdbcTemplate jdbc = dynamicJdbcService.getJdbcTemplate(dbName);
        String databaseType = dynamicJdbcService.getDatabaseType(dbName);
        if ("H2".equals(databaseType)) {
            String schemaName = resolveSchemaName(jdbc, databaseType);
            return H2SchemaIntrospector.introspect(jdbc, dbName, schemaName);
        }
        String schemaName = resolveSchemaName(jdbc, databaseType);

        List<TableMetaRow> tableRows = loadTables(jdbc, schemaName);
        List<ColumnMetaRow> columnRows = loadColumns(jdbc, schemaName);

        Map<String, TableSchema.TableSchemaBuilder> builders = new LinkedHashMap<>();
        for (TableMetaRow table : tableRows) {
            builders.put(table.tableName(), TableSchema.builder()
                    .tableName(table.tableName())
                    .tableComment(nullToEmpty(table.tableComment())));
        }

        for (ColumnMetaRow column : columnRows) {
            TableSchema.TableSchemaBuilder builder = builders.computeIfAbsent(
                    column.tableName(),
                    name -> TableSchema.builder().tableName(name).tableComment(""));
            builder.column(ColumnSchema.builder()
                    .columnName(column.columnName())
                    .dataType(column.dataType())
                    .nullable("YES".equalsIgnoreCase(column.nullable()))
                    .columnKey(nullToEmpty(column.columnKey()))
                    .comment(nullToEmpty(column.comment()))
                    .ordinalPosition(column.ordinalPosition())
                    .build());
        }

        DatabaseSchemaDescription.DatabaseSchemaDescriptionBuilder descriptionBuilder =
                DatabaseSchemaDescription.builder()
                        .dbName(dbName)
                        .schemaName(schemaName)
                        .databaseType(databaseType);
        builders.values().forEach(b -> descriptionBuilder.table(b.build()));
        return descriptionBuilder.build();
    }

    public String toStructuredJson(DatabaseSchemaDescription schema) {
        try {
            return objectMapper.writeValueAsString(schema);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Schema 序列化为 JSON 失败", e);
        }
    }

    public String toPromptText(DatabaseSchemaDescription schema) {
        StringBuilder sb = new StringBuilder();
        sb.append("数据库标识: ").append(schema.getDbName()).append('\n');
        sb.append("Schema: ").append(schema.getSchemaName()).append('\n');
        sb.append("方言: ").append(schema.getDatabaseType()).append('\n');
        if ("H2".equalsIgnoreCase(schema.getDatabaseType())) {
            sb.append("H2 说明: JDBC 使用 MODE=MySQL 兼容语法，但执行引擎为 H2；")
                    .append("表名/列名请与 Schema 大小写保持一致（DATABASE_TO_UPPER=false 时为小写）。")
                    .append('\n');
        }
        for (TableSchema table : schema.getTables()) {
            sb.append("\n表 ").append(table.getTableName());
            if (StringUtils.hasText(table.getTableComment())) {
                sb.append("（").append(table.getTableComment()).append(')');
            }
            sb.append(":\n");
            for (ColumnSchema column : table.getColumns()) {
                sb.append("  - ").append(column.getColumnName())
                        .append(' ').append(column.getDataType());
                if (StringUtils.hasText(column.getColumnKey())) {
                    sb.append(" [").append(column.getColumnKey()).append(']');
                }
                sb.append(column.isNullable() ? " NULL" : " NOT NULL");
                if (StringUtils.hasText(column.getComment())) {
                    sb.append(" /* ").append(column.getComment()).append(" */");
                }
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    private static String resolveSchemaName(JdbcTemplate jdbc, String databaseType) {
        if ("MYSQL".equals(databaseType)) {
            String name = jdbc.queryForObject("SELECT DATABASE()", String.class);
            if (!StringUtils.hasText(name)) {
                throw new IllegalStateException("MySQL 当前连接未选中数据库，请在 JDBC URL 中指定库名");
            }
            return name;
        }
        return jdbc.queryForObject("SELECT CURRENT_SCHEMA()", String.class);
    }

    private List<TableMetaRow> loadTables(JdbcTemplate jdbc, String schemaName) {
        return jdbc.query(
                """
                        SELECT TABLE_NAME, TABLE_COMMENT
                        FROM information_schema.TABLES
                        WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE'
                        ORDER BY TABLE_NAME
                        """,
                (rs, rowNum) -> new TableMetaRow(
                        rs.getString("TABLE_NAME"),
                        rs.getString("TABLE_COMMENT")),
                schemaName);
    }

    private List<ColumnMetaRow> loadColumns(JdbcTemplate jdbc, String schemaName) {
        return jdbc.query(
                """
                        SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE,
                               IFNULL(COLUMN_KEY, '') AS COLUMN_KEY,
                               IFNULL(COLUMN_COMMENT, '') AS COLUMN_COMMENT,
                               ORDINAL_POSITION
                        FROM information_schema.COLUMNS
                        WHERE TABLE_SCHEMA = ?
                        ORDER BY TABLE_NAME, ORDINAL_POSITION
                        """,
                (rs, rowNum) -> new ColumnMetaRow(
                        rs.getString("TABLE_NAME"),
                        rs.getString("COLUMN_NAME"),
                        rs.getString("COLUMN_TYPE"),
                        rs.getString("IS_NULLABLE"),
                        rs.getString("COLUMN_KEY"),
                        rs.getString("COLUMN_COMMENT"),
                        rs.getInt("ORDINAL_POSITION")),
                schemaName);
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    private record TableMetaRow(String tableName, String tableComment) {
    }

    private record ColumnMetaRow(
            String tableName,
            String columnName,
            String dataType,
            String nullable,
            String columnKey,
            String comment,
            int ordinalPosition) {
    }
}
