package com.example.text2sql.domain;

import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;

@Value
@Builder
public class ChatPendingRequest {
    Long id;
    String requestId;
    String dbName;
    String question;
    String generatedSql;
    String reasoning;
    ChatPendingStatus status;
    String operator;
    boolean securityPassed;
    LocalDateTime createdAt;
    LocalDateTime updatedAt;
}
