package com.example.text2sql.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;

@Configuration
public class AuditDataSourceConfig {

    @Bean(name = "auditDataSource")
    public DataSource auditDataSource(AuditDataSourceProperties properties) {
        if (!StringUtils.hasText(properties.getUrl())) {
            throw new IllegalStateException("审计库 JDBC URL 未配置，请检查 app.audit.datasource.url");
        }
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(properties.getUrl());
        dataSource.setUsername(properties.getUsername());
        if (StringUtils.hasText(properties.getPassword())) {
            dataSource.setPassword(properties.getPassword());
        }
        dataSource.setDriverClassName(properties.getDriverClassName());

        if (StringUtils.hasText(properties.getInitScript())) {
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
            populator.setSeparator(";");
            populator.setSqlScriptEncoding("UTF-8");
            populator.addScript(new DefaultResourceLoader().getResource(properties.getInitScript()));
            DatabasePopulatorUtils.execute(populator, dataSource);
        }
        return dataSource;
    }

    @Bean(name = "auditJdbcTemplate")
    public JdbcTemplate auditJdbcTemplate(
            @org.springframework.beans.factory.annotation.Qualifier("auditDataSource") DataSource auditDataSource) {
        return new JdbcTemplate(auditDataSource);
    }
}
