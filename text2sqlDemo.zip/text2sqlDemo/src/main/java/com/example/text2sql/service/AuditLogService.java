package com.example.text2sql.service;

import com.example.text2sql.domain.AuditActionType;
import com.example.text2sql.domain.AuditLog;
import com.example.text2sql.repository.AuditLogRepository;
import org.springframework.stereotype.Service;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void record(AuditLog log) {
        auditLogRepository.insert(log);
    }

    public void recordAsk(
            String requestId,
            String dbName,
            String operator,
            String question,
            String generatedSql,
            String reasoning,
            String status,
            boolean success,
            String errorMessage,
            String clientIp) {
        record(AuditLog.builder()
                .requestId(requestId)
                .actionType(AuditActionType.ASK)
                .dbName(dbName)
                .operator(operator)
                .question(question)
                .generatedSql(generatedSql)
                .reasoning(reasoning)
                .status(status)
                .success(success)
                .errorMessage(errorMessage)
                .clientIp(clientIp)
                .build());
    }

    public void recordExecute(
            String requestId,
            String dbName,
            String operator,
            String executedSql,
            String status,
            int rowCount,
            boolean success,
            String errorMessage,
            String clientIp) {
        record(AuditLog.builder()
                .requestId(requestId)
                .actionType(AuditActionType.EXECUTE)
                .dbName(dbName)
                .operator(operator)
                .executedSql(executedSql)
                .status(status)
                .resultRowCount(rowCount)
                .success(success)
                .errorMessage(errorMessage)
                .clientIp(clientIp)
                .build());
    }

    public void recordSecurityReject(
            String requestId,
            String dbName,
            String operator,
            String question,
            String sql,
            String errorMessage,
            String clientIp) {
        record(AuditLog.builder()
                .requestId(requestId)
                .actionType(AuditActionType.SECURITY_REJECT)
                .dbName(dbName)
                .operator(operator)
                .question(question)
                .generatedSql(sql)
                .executedSql(sql)
                .success(false)
                .errorMessage(errorMessage)
                .clientIp(clientIp)
                .build());
    }
}
