package com.example.text2sql.repository;

import com.example.text2sql.domain.AuditActionType;
import com.example.text2sql.domain.AuditLog;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AuditLogRepository {

    private final JdbcTemplate jdbcTemplate;

    public AuditLogRepository(@Qualifier("auditJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insert(AuditLog log) {
        jdbcTemplate.update(
                """
                        INSERT INTO t_audit_log
                        (request_id, action_type, db_name, operator, question, generated_sql,
                         executed_sql, reasoning, status, result_row_count, success, error_message, client_ip)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                log.getRequestId(),
                log.getActionType().name(),
                log.getDbName(),
                log.getOperator(),
                log.getQuestion(),
                log.getGeneratedSql(),
                log.getExecutedSql(),
                log.getReasoning(),
                log.getStatus(),
                log.getResultRowCount(),
                log.isSuccess() ? 1 : 0,
                log.getErrorMessage(),
                log.getClientIp());
    }
}
