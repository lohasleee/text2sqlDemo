package com.example.text2sql.repository;

import com.example.text2sql.domain.ChatPendingRequest;
import com.example.text2sql.domain.ChatPendingStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public class ChatPendingRepository {

    private final JdbcTemplate jdbcTemplate;

    public ChatPendingRepository(@Qualifier("auditJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void insert(ChatPendingRequest request) {
        jdbcTemplate.update(
                """
                        INSERT INTO t_chat_pending
                        (request_id, db_name, question, generated_sql, reasoning, status, operator, security_passed)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                request.getRequestId(),
                request.getDbName(),
                request.getQuestion(),
                request.getGeneratedSql(),
                request.getReasoning(),
                request.getStatus().name(),
                request.getOperator(),
                request.isSecurityPassed() ? 1 : 0);
    }

    public Optional<ChatPendingRequest> findByRequestId(String requestId) {
        return jdbcTemplate.query(
                        """
                                SELECT id, request_id, db_name, question, generated_sql, reasoning,
                                       status, operator, security_passed, created_at, updated_at
                                FROM t_chat_pending WHERE request_id = ?
                                """,
                        rowMapper(),
                        requestId)
                .stream()
                .findFirst();
    }

    public void updateStatus(String requestId, ChatPendingStatus status) {
        jdbcTemplate.update(
                "UPDATE t_chat_pending SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE request_id = ?",
                status.name(),
                requestId);
    }

    private static RowMapper<ChatPendingRequest> rowMapper() {
        return (rs, rowNum) -> ChatPendingRequest.builder()
                .id(rs.getLong("id"))
                .requestId(rs.getString("request_id"))
                .dbName(rs.getString("db_name"))
                .question(rs.getString("question"))
                .generatedSql(rs.getString("generated_sql"))
                .reasoning(rs.getString("reasoning"))
                .status(ChatPendingStatus.valueOf(rs.getString("status")))
                .operator(rs.getString("operator"))
                .securityPassed(rs.getInt("security_passed") == 1)
                .createdAt(toLocalDateTime(rs.getTimestamp("created_at")))
                .updatedAt(toLocalDateTime(rs.getTimestamp("updated_at")))
                .build();
    }

    private static LocalDateTime toLocalDateTime(Timestamp timestamp) {
        return timestamp == null ? null : timestamp.toLocalDateTime();
    }
}
