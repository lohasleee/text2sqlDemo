package com.example.text2sql.service;

import com.example.text2sql.ai.Text2SqlResponse;
import com.example.text2sql.metadata.DatabaseSchemaDescription;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class Text2SqlService {

    private static final String USER_PROMPT = """
            请根据以下信息生成 SQL。

            【databaseType】
            {databaseType}

            【Schema JSON】
            {schemaJson}

            【Schema 可读描述】
            {schemaText}

            【用户问题】
            {question}

            请返回 JSON，且仅包含两个字段：sql（字符串）、reasoning（字符串，中文说明思路）。
            """;

    private final ChatClient text2SqlChatClient;
    private final MetadataService metadataService;
    private final StubText2SqlGenerator stubText2SqlGenerator;
    private final String provider;

    public Text2SqlService(
            @Qualifier("text2SqlChatClient") ChatClient text2SqlChatClient,
            MetadataService metadataService,
            StubText2SqlGenerator stubText2SqlGenerator,
            @Value("${app.text2sql.provider:stub}") String provider) {
        this.text2SqlChatClient = text2SqlChatClient;
        this.metadataService = metadataService;
        this.stubText2SqlGenerator = stubText2SqlGenerator;
        this.provider = provider;
    }

    public Text2SqlResponse generate(String dbName, String question) {
        if (!StringUtils.hasText(question)) {
            throw new IllegalArgumentException("question 不能为空");
        }
        DatabaseSchemaDescription schema = metadataService.loadSchema(dbName);
        return generateWithSchema(dbName, question, schema);
    }

    public Text2SqlResponse generate(String dbName, String question, DatabaseSchemaDescription schema) {
        if (!StringUtils.hasText(question)) {
            throw new IllegalArgumentException("question 不能为空");
        }
        return generateWithSchema(dbName, question, schema);
    }

    private Text2SqlResponse generateWithSchema(
            String dbName,
            String question,
            DatabaseSchemaDescription schema) {
        if (useStubProvider()) {
            return stubText2SqlGenerator.generate(dbName, question, schema);
        }
        return generateWithAi(question, schema);
    }

    private boolean useStubProvider() {
        return !"ai".equalsIgnoreCase(String.valueOf(provider).trim());
    }

    private Text2SqlResponse generateWithAi(String question, DatabaseSchemaDescription schema) {
        String schemaJson = metadataService.toStructuredJson(schema);
        String schemaText = metadataService.toPromptText(schema);
        String databaseType = schema.getDatabaseType();
        String dialectHint = "H2".equalsIgnoreCase(databaseType)
                ? "（H2 内嵌库，MODE=MySQL，表/列名按 Schema 小写书写）"
                : "（MySQL）";

        return text2SqlChatClient.prompt()
                .user(user -> user.text(USER_PROMPT)
                        .param("databaseType", databaseType + dialectHint)
                        .param("schemaJson", schemaJson)
                        .param("schemaText", schemaText)
                        .param("question", question.trim()))
                .call()
                .entity(Text2SqlResponse.class);
    }
}
