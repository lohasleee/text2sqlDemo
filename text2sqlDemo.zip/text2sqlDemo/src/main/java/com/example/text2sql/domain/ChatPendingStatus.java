package com.example.text2sql.domain;

public enum ChatPendingStatus {
    PENDING_REVIEW,
    EXECUTED,
    REJECTED
}
