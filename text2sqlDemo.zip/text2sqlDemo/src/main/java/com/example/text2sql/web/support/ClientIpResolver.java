package com.example.text2sql.web.support;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.util.StringUtils;

public final class ClientIpResolver {

    private ClientIpResolver() {
    }

    public static String resolve(HttpServletRequest request) {
        Object attr = request.getAttribute(AuditLoggingInterceptor.ATTR_CLIENT_IP);
        if (attr instanceof String s && StringUtils.hasText(s)) {
            return s;
        }
        String forwarded = request.getHeader("X-Forwarded-For");
        if (StringUtils.hasText(forwarded)) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
