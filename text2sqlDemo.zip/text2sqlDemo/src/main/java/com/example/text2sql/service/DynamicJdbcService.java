package com.example.text2sql.service;

import com.example.text2sql.config.MultiDataSourceProperties;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class DynamicJdbcService {

    private final JdbcTemplate customerJdbcTemplate;
    private final JdbcTemplate orderJdbcTemplate;
    private final MultiDataSourceProperties dataSourceProperties;

    public DynamicJdbcService(
            @Qualifier("customerJdbcTemplate") JdbcTemplate customerJdbcTemplate,
            @Qualifier("orderJdbcTemplate") JdbcTemplate orderJdbcTemplate,
            MultiDataSourceProperties dataSourceProperties) {
        this.customerJdbcTemplate = customerJdbcTemplate;
        this.orderJdbcTemplate = orderJdbcTemplate;
        this.dataSourceProperties = dataSourceProperties;
    }

    public JdbcTemplate getJdbcTemplate(String dbName) {
        if (dbName == null) {
            throw new IllegalArgumentException("dbName 不能为空");
        }
        return switch (dbName.trim().toLowerCase()) {
            case "customer" -> customerJdbcTemplate;
            case "order" -> orderJdbcTemplate;
            default -> throw new IllegalArgumentException(
                    "未知数据源: " + dbName + "，仅支持 customer、order");
        };
    }

    public String getDatabaseType(String dbName) {
        if (dbName == null) {
            throw new IllegalArgumentException("dbName 不能为空");
        }
        String type = switch (dbName.trim().toLowerCase()) {
            case "customer" -> dataSourceProperties.getCustomer().getDatabaseType();
            case "order" -> dataSourceProperties.getOrder().getDatabaseType();
            default -> throw new IllegalArgumentException(
                    "未知数据源: " + dbName + "，仅支持 customer、order");
        };
        return normalizeDatabaseType(type);
    }

    private static String normalizeDatabaseType(String type) {
        if (!String.valueOf(type).isBlank()
                && "MYSQL".equalsIgnoreCase(type.trim())) {
            return "MYSQL";
        }
        return "H2";
    }
}
