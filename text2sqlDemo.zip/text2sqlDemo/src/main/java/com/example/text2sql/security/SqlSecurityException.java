package com.example.text2sql.security;

/**
 * SQL 安全校验未通过时抛出。
 */
public class SqlSecurityException extends RuntimeException {

    public SqlSecurityException(String message) {
        super(message);
    }
}
