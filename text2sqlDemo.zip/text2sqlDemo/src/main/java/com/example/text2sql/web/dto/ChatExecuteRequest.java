package com.example.text2sql.web.dto;

import jakarta.validation.constraints.NotBlank;

public record ChatExecuteRequest(
        String requestId,
        @NotBlank(message = "dbName 不能为空") String dbName,
        @NotBlank(message = "sql 不能为空") String sql,
        String operator) {
}
