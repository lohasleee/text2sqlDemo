package com.example.text2sql.web.support;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 在 Controller 进入前解析操作人、客户端 IP，供审计与业务层使用。
 */
@Component
public class AuditLoggingInterceptor implements HandlerInterceptor {

    public static final String ATTR_OPERATOR = "audit.operator";
    public static final String ATTR_CLIENT_IP = "audit.clientIp";
    public static final String ATTR_REQUEST_START = "audit.requestStartMs";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        request.setAttribute(ATTR_REQUEST_START, System.currentTimeMillis());
        request.setAttribute(ATTR_CLIENT_IP, resolveClientIp(request));
        request.setAttribute(ATTR_OPERATOR, resolveOperatorHeader(request));
        return true;
    }

    private static String resolveOperatorHeader(HttpServletRequest request) {
        String header = request.getHeader(OperatorResolver.HEADER_OPERATOR);
        return StringUtils.hasText(header) ? header.trim() : null;
    }

    private static String resolveClientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (StringUtils.hasText(forwarded)) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
