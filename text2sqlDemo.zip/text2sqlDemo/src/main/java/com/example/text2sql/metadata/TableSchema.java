package com.example.text2sql.metadata;

import lombok.Builder;
import lombok.Singular;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class TableSchema {
    String tableName;
    String tableComment;
    @Singular
    List<ColumnSchema> columns;
}
