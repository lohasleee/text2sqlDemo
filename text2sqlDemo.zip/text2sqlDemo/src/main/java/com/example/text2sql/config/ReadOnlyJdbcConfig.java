package com.example.text2sql.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class ReadOnlyJdbcConfig {

    @Bean(name = "customerReadOnlyDataSource")
    public DataSource customerReadOnlyDataSource(
            @Qualifier("customerDataSource") DataSource customerDataSource) {
        return new ReadOnlyDataSource(customerDataSource);
    }

    @Bean(name = "orderReadOnlyDataSource")
    public DataSource orderReadOnlyDataSource(
            @Qualifier("orderDataSource") DataSource orderDataSource) {
        return new ReadOnlyDataSource(orderDataSource);
    }

    @Bean(name = "customerReadOnlyJdbcTemplate")
    public JdbcTemplate customerReadOnlyJdbcTemplate(
            @Qualifier("customerReadOnlyDataSource") DataSource customerReadOnlyDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(customerReadOnlyDataSource);
        jdbcTemplate.setMaxRows(1000);
        jdbcTemplate.setQueryTimeout(30);
        return jdbcTemplate;
    }

    @Bean(name = "orderReadOnlyJdbcTemplate")
    public JdbcTemplate orderReadOnlyJdbcTemplate(
            @Qualifier("orderReadOnlyDataSource") DataSource orderReadOnlyDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(orderReadOnlyDataSource);
        jdbcTemplate.setMaxRows(1000);
        jdbcTemplate.setQueryTimeout(30);
        return jdbcTemplate;
    }
}
