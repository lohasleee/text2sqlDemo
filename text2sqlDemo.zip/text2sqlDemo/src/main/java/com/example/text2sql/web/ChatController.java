package com.example.text2sql.web;

import com.example.text2sql.service.ChatApplicationService;
import com.example.text2sql.web.dto.ChatAskRequest;
import com.example.text2sql.web.dto.ChatAskResponse;
import com.example.text2sql.web.dto.ChatExecuteRequest;
import com.example.text2sql.web.dto.ChatExecuteResponse;
import com.example.text2sql.web.support.ClientIpResolver;
import com.example.text2sql.web.support.OperatorResolver;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatApplicationService chatApplicationService;

    public ChatController(ChatApplicationService chatApplicationService) {
        this.chatApplicationService = chatApplicationService;
    }

    @PostMapping("/ask")
    @ResponseStatus(HttpStatus.OK)
    public ChatAskResponse ask(
            @Valid @RequestBody ChatAskRequest request,
            HttpServletRequest httpRequest) {
        String operator = OperatorResolver.resolve(request.operator(), httpRequest);
        String clientIp = ClientIpResolver.resolve(httpRequest);
        return chatApplicationService.ask(
                request.dbName(),
                request.question(),
                operator,
                clientIp);
    }

    @PostMapping("/execute")
    @ResponseStatus(HttpStatus.OK)
    public ChatExecuteResponse execute(
            @Valid @RequestBody ChatExecuteRequest request,
            HttpServletRequest httpRequest) {
        String operator = OperatorResolver.resolve(request.operator(), httpRequest);
        String clientIp = ClientIpResolver.resolve(httpRequest);
        return chatApplicationService.execute(
                request.requestId(),
                request.dbName(),
                request.sql(),
                operator,
                clientIp);
    }
}
