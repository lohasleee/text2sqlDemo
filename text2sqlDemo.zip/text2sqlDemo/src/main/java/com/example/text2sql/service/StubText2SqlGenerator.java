package com.example.text2sql.service;

import com.example.text2sql.ai.Text2SqlResponse;
import com.example.text2sql.metadata.DatabaseSchemaDescription;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * 无 Ollama/OpenAI 时的规则演示生成器，便于本地 H2 联调全流程。
 */
@Component
public class StubText2SqlGenerator {

    public Text2SqlResponse generate(String dbName, String question, DatabaseSchemaDescription schema) {
        String q = question.toLowerCase();
        String table = schema.getTables().isEmpty()
                ? ("customer".equals(dbName) ? "t_customer" : "t_order")
                : schema.getTables().get(0).getTableName();

        if ("customer".equals(dbName)) {
            return generateCustomer(q, table);
        }
        return generateOrder(q, table);
    }

    private static Text2SqlResponse generateCustomer(String q, String table) {
        if (containsAny(q, "vip", "贵宾")) {
            return response(
                    "SELECT customer_name, phone, region, level, create_time FROM " + table
                            + " WHERE level = 'VIP'",
                    "【演示模式】识别到 VIP 条件，查询客户库 t_customer 中 level='VIP' 的记录。");
        }
        if (containsAny(q, "金卡", "gold")) {
            return response(
                    "SELECT customer_name, phone, region, level FROM " + table + " WHERE level = 'GOLD'",
                    "【演示模式】按客户等级 GOLD 过滤。");
        }
        if (containsAny(q, "数量", "多少", "count", "几个")) {
            return response(
                    "SELECT COUNT(*) AS cnt FROM " + table,
                    "【演示模式】统计客户总数。");
        }
        if (containsAny(q, "深圳", "华南")) {
            return response(
                    "SELECT customer_name, phone, region, level FROM " + table
                            + " WHERE region LIKE '%深圳%' OR region LIKE '%华南%'",
                    "【演示模式】按 region 模糊匹配深圳/华南。");
        }
        return response(
                "SELECT customer_name, phone, region, level, create_time FROM " + table + " LIMIT 20",
                "【演示模式】未匹配到细粒度意图，返回客户表前 20 行。接入 Ollama 后可自然语言生成更精准 SQL。");
    }

    private static Text2SqlResponse generateOrder(String q, String table) {
        if (containsAny(q, "待支付", "未支付", "status", "0")) {
            return response(
                    "SELECT order_no, customer_id, amount, status, order_date FROM " + table
                            + " WHERE status = 0",
                    "【演示模式】查询 status=0（待支付）的订单。");
        }
        if (containsAny(q, "金额", "sum", "合计", "总")) {
            return response(
                    "SELECT SUM(amount) AS total_amount FROM " + table,
                    "【演示模式】汇总订单金额。");
        }
        if (containsAny(q, "客户", "customer_id", "1")) {
            return response(
                    "SELECT order_no, amount, status, order_date FROM " + table
                            + " WHERE customer_id = 1",
                    "【演示模式】查询 customer_id=1 的订单。");
        }
        return response(
                "SELECT order_no, customer_id, amount, status, order_date FROM " + table
                        + " ORDER BY order_date DESC LIMIT 20",
                "【演示模式】返回最近 20 条订单。配置 app.text2sql.provider=ai 并启动 Ollama 后可使用大模型。");
    }

    private static boolean containsAny(String text, String... keywords) {
        for (String kw : keywords) {
            if (StringUtils.hasText(kw) && text.contains(kw.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private static Text2SqlResponse response(String sql, String reasoning) {
        return new Text2SqlResponse(sql, reasoning);
    }
}
