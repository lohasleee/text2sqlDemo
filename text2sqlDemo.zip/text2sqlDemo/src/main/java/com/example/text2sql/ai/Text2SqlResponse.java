package com.example.text2sql.ai;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;

/**
 * 大模型 Text2SQL 结构化输出（仅包含 sql 与 reasoning 两个字段）。
 */
public record Text2SqlResponse(
        @JsonPropertyDescription("可直接执行的 SQL 语句，不要包含 Markdown 代码块")
        String sql,
        @JsonPropertyDescription("生成该 SQL 的思路说明，使用中文")
        String reasoning) {
}
