package com.example.text2sql.metadata;

import lombok.Builder;
import lombok.Singular;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class DatabaseSchemaDescription {
    String dbName;
    String schemaName;
    String databaseType;
    @Singular
    List<TableSchema> tables;
}
