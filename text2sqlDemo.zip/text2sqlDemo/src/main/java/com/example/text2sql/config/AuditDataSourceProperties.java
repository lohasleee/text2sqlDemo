package com.example.text2sql.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "app.audit.datasource")
public class AuditDataSourceProperties {
    private String url;
    private String username = "sa";
    private String password = "";
    private String driverClassName = "org.h2.Driver";
    private String initScript = "classpath:db/init-audit-db.sql";
}
