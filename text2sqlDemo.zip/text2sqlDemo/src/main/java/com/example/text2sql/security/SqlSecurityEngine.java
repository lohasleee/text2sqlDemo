package com.example.text2sql.security;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 对大模型生成的 SQL 做静态安全校验（面向 H2 / MySQL 常见注入与误用场景）。
 */
@Component
public class SqlSecurityEngine {

    private static final Pattern FORBIDDEN_KEYWORD = Pattern.compile(
            "\\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|REPLACE|MERGE|GRANT|REVOKE|"
                    + "EXECUTE|EXEC|CALL|LOAD|RENAME|ATTACH|DETACH|PRAGMA|SHUTDOWN|KILL|COPY|"
                    + "VACUUM|ANALYZE|COMMENT|LOCK|UNLOCK)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern FORBIDDEN_SET = Pattern.compile(
            "\\bSET\\s+(GLOBAL|SESSION)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern DANGEROUS_FUNCTION = Pattern.compile(
            "\\b(SLEEP|BENCHMARK|LOAD_FILE|PG_SLEEP|SYS_EVAL|WAITFOR|DELAY|GET_LOCK|RELEASE_LOCK|"
                    + "MASTER_POS_WAIT|DBMS_LOCK)\\s*\\(",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern INTO_DANGEROUS = Pattern.compile(
            "\\bINTO\\s+(OUTFILE|DUMPFILE|TABLE|\\S+\\.)",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern UNION_INJECTION_HINT = Pattern.compile(
            "\\bUNION\\s+(ALL\\s+)?SELECT\\b",
            Pattern.CASE_INSENSITIVE);

    public void validate(String sql) {
        if (!StringUtils.hasText(sql)) {
            throw new SqlSecurityException("SQL 不能为空");
        }

        String trimmed = sql.trim();
        if (trimmed.length() > 10_000) {
            throw new SqlSecurityException("SQL 长度超过允许上限（10000 字符）");
        }

        rejectMultiStatement(trimmed);

        String normalized = normalizeForInspection(trimmed);
        requireSelectOnly(normalized);
        rejectForbiddenKeywords(normalized);
        rejectForbiddenSet(normalized);
        rejectDangerousFunctions(normalized);
        rejectIntoOutfile(normalized);
    }

    private static void rejectMultiStatement(String sql) {
        String withoutTrailing = sql;
        while (withoutTrailing.endsWith(";")) {
            withoutTrailing = withoutTrailing.substring(0, withoutTrailing.length() - 1).trim();
        }
        if (withoutTrailing.contains(";")) {
            throw new SqlSecurityException("禁止多语句查询：检测到分号（;）拼接多条 SQL");
        }
    }

    private static void requireSelectOnly(String normalized) {
        if (!normalized.regionMatches(true, 0, "SELECT", 0, "SELECT".length())) {
            throw new SqlSecurityException("仅允许 SELECT 查询语句");
        }
        if (normalized.regionMatches(true, 0, "SELECT", 0, "SELECT".length())) {
            int afterSelect = skipWhitespace(normalized, "SELECT".length());
            if (afterSelect >= normalized.length()) {
                throw new SqlSecurityException("SELECT 语句不完整");
            }
        }
    }

    private static void rejectForbiddenKeywords(String normalized) {
        Matcher matcher = FORBIDDEN_KEYWORD.matcher(normalized);
        if (matcher.find()) {
            throw new SqlSecurityException(
                    "检测到禁止的 SQL 关键字: " + matcher.group(1).toUpperCase());
        }
    }

    private static void rejectForbiddenSet(String normalized) {
        Matcher matcher = FORBIDDEN_SET.matcher(normalized);
        if (matcher.find()) {
            throw new SqlSecurityException("禁止 SET GLOBAL/SESSION 类会话篡改语句");
        }
    }

    private static void rejectDangerousFunctions(String normalized) {
        Matcher matcher = DANGEROUS_FUNCTION.matcher(normalized);
        if (matcher.find()) {
            throw new SqlSecurityException(
                    "检测到高危函数或调用: " + matcher.group(1));
        }
    }

    private static void rejectIntoOutfile(String normalized) {
        Matcher matcher = INTO_DANGEROUS.matcher(normalized);
        if (matcher.find()) {
            throw new SqlSecurityException("禁止 SELECT ... INTO 文件/表等写操作语法");
        }
        Matcher union = UNION_INJECTION_HINT.matcher(normalized);
        if (union.find() && !normalized.regionMatches(true, 0, "SELECT", 0, 6)) {
            throw new SqlSecurityException("不允许非 SELECT 开头的 UNION 查询");
        }
    }

    /**
     * 去除注释并压缩空白，便于关键字检测（不用于执行）。
     */
    static String normalizeForInspection(String sql) {
        String noBlock = removeBlockComments(sql);
        String noLine = removeLineComments(noBlock);
        return noLine.replaceAll("\\s+", " ").trim();
    }

    private static String removeBlockComments(String sql) {
        StringBuilder sb = new StringBuilder(sql.length());
        int i = 0;
        while (i < sql.length()) {
            if (i + 1 < sql.length() && sql.charAt(i) == '/' && sql.charAt(i + 1) == '*') {
                i += 2;
                while (i + 1 < sql.length() && !(sql.charAt(i) == '*' && sql.charAt(i + 1) == '/')) {
                    i++;
                }
                i = Math.min(i + 2, sql.length());
                sb.append(' ');
                continue;
            }
            sb.append(sql.charAt(i));
            i++;
        }
        return sb.toString();
    }

    private static String removeLineComments(String sql) {
        StringBuilder sb = new StringBuilder(sql.length());
        boolean inSingleQuote = false;
        for (int i = 0; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (c == '\'') {
                if (inSingleQuote && i + 1 < sql.length() && sql.charAt(i + 1) == '\'') {
                    sb.append("''");
                    i++;
                    continue;
                }
                inSingleQuote = !inSingleQuote;
                sb.append(c);
                continue;
            }
            if (!inSingleQuote && i + 1 < sql.length() && sql.charAt(i) == '-' && sql.charAt(i + 1) == '-') {
                while (i < sql.length() && sql.charAt(i) != '\n') {
                    i++;
                }
                sb.append(' ');
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static int skipWhitespace(String s, int from) {
        int i = from;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }
}
