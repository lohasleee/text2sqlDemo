package com.example.text2sql.service;

import com.example.text2sql.security.SqlSecurityEngine;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 先经 {@link SqlSecurityEngine} 校验，再通过只读 {@link JdbcTemplate} 执行查询。
 */
@Service
public class SafeSqlQueryService {

    private final SqlSecurityEngine sqlSecurityEngine;
    private final JdbcTemplate customerReadOnlyJdbcTemplate;
    private final JdbcTemplate orderReadOnlyJdbcTemplate;

    public SafeSqlQueryService(
            SqlSecurityEngine sqlSecurityEngine,
            @Qualifier("customerReadOnlyJdbcTemplate") JdbcTemplate customerReadOnlyJdbcTemplate,
            @Qualifier("orderReadOnlyJdbcTemplate") JdbcTemplate orderReadOnlyJdbcTemplate) {
        this.sqlSecurityEngine = sqlSecurityEngine;
        this.customerReadOnlyJdbcTemplate = customerReadOnlyJdbcTemplate;
        this.orderReadOnlyJdbcTemplate = orderReadOnlyJdbcTemplate;
    }

    public List<Map<String, Object>> query(String dbName, String sql) {
        sqlSecurityEngine.validate(sql);
        return resolveReadOnlyTemplate(dbName).queryForList(sql);
    }

    private JdbcTemplate resolveReadOnlyTemplate(String dbName) {
        if (dbName == null) {
            throw new IllegalArgumentException("dbName 不能为空");
        }
        return switch (dbName.trim().toLowerCase()) {
            case "customer" -> customerReadOnlyJdbcTemplate;
            case "order" -> orderReadOnlyJdbcTemplate;
            default -> throw new IllegalArgumentException(
                    "未知数据源: " + dbName + "，仅支持 customer、order");
        };
    }
}
