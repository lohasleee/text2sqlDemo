package com.example.text2sql.metadata;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 通过 JDBC DatabaseMetaData 读取 H2 表结构（含 REMARKS 中文注释），适配 MODE=MySQL 与 DATABASE_TO_UPPER=false。
 */
public final class H2SchemaIntrospector {

    private H2SchemaIntrospector() {
    }

    public static DatabaseSchemaDescription introspect(
            JdbcTemplate jdbc,
            String dbName,
            String schemaName) {
        DataSource dataSource = jdbc.getDataSource();
        if (dataSource == null) {
            throw new IllegalStateException("JdbcTemplate 未关联 DataSource");
        }
        try (Connection connection = dataSource.getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            String catalog = connection.getCatalog();
            String effectiveSchema = resolveEffectiveSchema(metaData, connection, schemaName);

            Map<String, TableSchema.TableSchemaBuilder> tableBuilders = new LinkedHashMap<>();
            loadTables(metaData, catalog, effectiveSchema, tableBuilders);
            loadColumnsAndKeys(metaData, catalog, effectiveSchema, tableBuilders);

            DatabaseSchemaDescription.DatabaseSchemaDescriptionBuilder builder =
                    DatabaseSchemaDescription.builder()
                            .dbName(dbName)
                            .schemaName(effectiveSchema)
                            .databaseType("H2");
            tableBuilders.values().forEach(b -> builder.table(b.build()));
            return builder.build();
        } catch (SQLException e) {
            throw new IllegalStateException("读取 H2 Schema 元数据失败", e);
        }
    }

    private static String resolveEffectiveSchema(
            DatabaseMetaData metaData,
            Connection connection,
            String schemaName) throws SQLException {
        if (StringUtils.hasText(schemaName)) {
            return schemaName;
        }
        String current = connection.getSchema();
        if (StringUtils.hasText(current)) {
            return current;
        }
        return metaData.storesUpperCaseIdentifiers() ? "PUBLIC" : "public";
    }

    private static void loadTables(
            DatabaseMetaData metaData,
            String catalog,
            String schema,
            Map<String, TableSchema.TableSchemaBuilder> tableBuilders) throws SQLException {
        try (ResultSet tables = metaData.getTables(catalog, schema, null, new String[]{"TABLE"})) {
            while (tables.next()) {
                String tableName = tables.getString("TABLE_NAME");
                if (!StringUtils.hasText(tableName) || isSystemTable(tableName)) {
                    continue;
                }
                tableBuilders.put(tableName, TableSchema.builder()
                        .tableName(tableName)
                        .tableComment(nullToEmpty(tables.getString("REMARKS"))));
            }
        }
    }

    private static void loadColumnsAndKeys(
            DatabaseMetaData metaData,
            String catalog,
            String schema,
            Map<String, TableSchema.TableSchemaBuilder> tableBuilders) throws SQLException {
        for (String tableName : tableBuilders.keySet()) {
            Set<String> primaryKeys = loadPrimaryKeys(metaData, catalog, schema, tableName);
            TableSchema.TableSchemaBuilder tableBuilder = tableBuilders.get(tableName);
            Map<Integer, ColumnSchema> orderedColumns = new TreeMap<>();

            try (ResultSet columns = metaData.getColumns(catalog, schema, tableName, null)) {
                while (columns.next()) {
                    String columnName = columns.getString("COLUMN_NAME");
                    String typeName = columns.getString("TYPE_NAME");
                    int nullable = columns.getInt("NULLABLE");
                    int ordinal = columns.getInt("ORDINAL_POSITION");
                    String remarks = columns.getString("REMARKS");
                    String columnSize = columns.getString("COLUMN_SIZE");

                    orderedColumns.put(ordinal, ColumnSchema.builder()
                            .columnName(columnName)
                            .dataType(formatH2DataType(typeName, columnSize))
                            .nullable(nullable == DatabaseMetaData.columnNullable)
                            .columnKey(primaryKeys.contains(columnName) ? "PRI" : "")
                            .comment(nullToEmpty(remarks))
                            .ordinalPosition(ordinal)
                            .build());
                }
            }
            orderedColumns.values().forEach(tableBuilder::column);
        }
    }

    private static Set<String> loadPrimaryKeys(
            DatabaseMetaData metaData,
            String catalog,
            String schema,
            String tableName) throws SQLException {
        Set<String> keys = new HashSet<>();
        try (ResultSet pk = metaData.getPrimaryKeys(catalog, schema, tableName)) {
            while (pk.next()) {
                keys.add(pk.getString("COLUMN_NAME"));
            }
        }
        return keys;
    }

    private static String formatH2DataType(String typeName, String columnSize) {
        if (!StringUtils.hasText(typeName)) {
            return "UNKNOWN";
        }
        if (!StringUtils.hasText(columnSize) || "0".equals(columnSize)) {
            return typeName;
        }
        if ("VARCHAR".equalsIgnoreCase(typeName)
                || "CHAR".equalsIgnoreCase(typeName)
                || "DECIMAL".equalsIgnoreCase(typeName)
                || "NUMERIC".equalsIgnoreCase(typeName)) {
            return typeName + "(" + columnSize + ")";
        }
        return typeName;
    }

    private static boolean isSystemTable(String tableName) {
        String upper = tableName.toUpperCase();
        return upper.startsWith("INFORMATION_SCHEMA")
                || upper.startsWith("PG_")
                || "CONSTANTS".equals(upper)
                || "ENUM_VALUES".equals(upper);
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value.trim();
    }
}
