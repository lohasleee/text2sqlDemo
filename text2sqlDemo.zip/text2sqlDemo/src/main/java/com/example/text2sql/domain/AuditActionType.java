package com.example.text2sql.domain;

public enum AuditActionType {
    ASK,
    EXECUTE,
    SECURITY_REJECT
}
