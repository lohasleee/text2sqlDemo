package com.example.text2sql.config;

import org.springframework.jdbc.datasource.AbstractDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 包装已有 DataSource，在每次获取连接时强制 {@link Connection#setReadOnly(true)}。
 */
public class ReadOnlyDataSource extends AbstractDataSource {

    private final DataSource delegate;

    public ReadOnlyDataSource(DataSource delegate) {
        this.delegate = delegate;
    }

    @Override
    public Connection getConnection() throws SQLException {
        return configureReadOnly(delegate.getConnection());
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        return configureReadOnly(delegate.getConnection(username, password));
    }

    private static Connection configureReadOnly(Connection connection) throws SQLException {
        connection.setReadOnly(true);
        connection.setAutoCommit(true);
        return connection;
    }
}
