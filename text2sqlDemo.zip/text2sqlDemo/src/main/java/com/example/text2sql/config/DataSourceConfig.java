package com.example.text2sql.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Bean(name = "customerDataSource")
    public DataSource customerDataSource(MultiDataSourceProperties properties) {
        MultiDataSourceProperties.DataSourceItem item = properties.getCustomer();
        DataSource dataSource = buildDataSource(item);
        runInitScript(dataSource, item.getInitScript());
        return dataSource;
    }

    @Bean(name = "orderDataSource")
    public DataSource orderDataSource(MultiDataSourceProperties properties) {
        MultiDataSourceProperties.DataSourceItem item = properties.getOrder();
        DataSource dataSource = buildDataSource(item);
        runInitScript(dataSource, item.getInitScript());
        return dataSource;
    }

    @Bean(name = "customerJdbcTemplate")
    public JdbcTemplate customerJdbcTemplate(
            @Qualifier("customerDataSource") DataSource customerDataSource) {
        return new JdbcTemplate(customerDataSource);
    }

    @Bean(name = "orderJdbcTemplate")
    public JdbcTemplate orderJdbcTemplate(
            @Qualifier("orderDataSource") DataSource orderDataSource) {
        return new JdbcTemplate(orderDataSource);
    }

    private static DataSource buildDataSource(MultiDataSourceProperties.DataSourceItem item) {
        if (!StringUtils.hasText(item.getUrl())) {
            throw new IllegalStateException("数据源 JDBC URL 未配置，请检查 app.datasource.*.url");
        }
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(item.getUrl());
        dataSource.setUsername(item.getUsername());
        if (StringUtils.hasText(item.getPassword())) {
            dataSource.setPassword(item.getPassword());
        }
        if (StringUtils.hasText(item.getDriverClassName())) {
            dataSource.setDriverClassName(item.getDriverClassName());
        }
        return dataSource;
    }

    private static void runInitScript(DataSource dataSource, String scriptLocation) {
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.setContinueOnError(false);
        populator.setSeparator(";");
        populator.setSqlScriptEncoding("UTF-8");
        Resource resource = new DefaultResourceLoader().getResource(scriptLocation);
        populator.addScript(resource);
        DatabasePopulatorUtils.execute(populator, dataSource);
    }
}
