package com.example.text2sql.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "app.datasource")
public class MultiDataSourceProperties {

    @NestedConfigurationProperty
    private DataSourceItem customer = new DataSourceItem();

    @NestedConfigurationProperty
    private DataSourceItem order = new DataSourceItem();

    @Getter
    @Setter
    public static class DataSourceItem {
        /** H2 或 MYSQL，用于后续 SQL 方言选择 */
        private String databaseType = "H2";
        private String url;
        private String username;
        private String password;
        private String driverClassName;
        private String initScript;
    }
}
