package com.example.text2sql.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AiConfig {

    private static final String TEXT2SQL_SYSTEM = """
            你是专业的 Text2SQL 助手。根据给定的数据库 Schema 与用户问题，生成安全、可执行的只读查询 SQL。
            规则：
            1. 默认只生成 SELECT 语句，禁止 INSERT/UPDATE/DELETE/DDL。
            2. 严格使用 Schema 中存在的表名与字段名；databaseType 为 H2 或 MYSQL。
            3. 当 databaseType=H2 时：当前以 H2 为主力库（常开 MODE=MySQL），优先使用 H2/MySQL 通用语法（如 LIMIT）；
               表名/列名必须与 Schema 完全一致（未加引号时通常为小写）；避免 MySQL 专属且 H2 不支持的函数。
            4. 当 databaseType=MYSQL 时：使用 MySQL 方言（information_schema 注释已体现在 Schema 中）。
            5. 若信息不足无法生成 SQL，sql 置为空字符串，在 reasoning 中说明原因。
            6. 必须按要求的 JSON 结构输出，且只输出 JSON，不要 Markdown 或其它前后缀。
            """;

    @Bean
    public ChatClient text2SqlChatClient(ChatClient.Builder chatClientBuilder) {
        return chatClientBuilder
                .defaultSystem(TEXT2SQL_SYSTEM)
                .build();
    }
}
