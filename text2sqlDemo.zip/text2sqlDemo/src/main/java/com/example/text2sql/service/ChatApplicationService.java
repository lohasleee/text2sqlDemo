package com.example.text2sql.service;

import com.example.text2sql.ai.Text2SqlResponse;
import com.example.text2sql.domain.ChatPendingRequest;
import com.example.text2sql.domain.ChatPendingStatus;
import com.example.text2sql.security.SqlSecurityEngine;
import com.example.text2sql.security.SqlSecurityException;
import com.example.text2sql.repository.ChatPendingRepository;
import com.example.text2sql.web.dto.ChatAskResponse;
import com.example.text2sql.web.dto.ChatExecuteResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Service
public class ChatApplicationService {

    private final Text2SqlService text2SqlService;
    private final SqlSecurityEngine sqlSecurityEngine;
    private final SafeSqlQueryService safeSqlQueryService;
    private final ChatPendingRepository chatPendingRepository;
    private final AuditLogService auditLogService;

    public ChatApplicationService(
            Text2SqlService text2SqlService,
            SqlSecurityEngine sqlSecurityEngine,
            SafeSqlQueryService safeSqlQueryService,
            ChatPendingRepository chatPendingRepository,
            AuditLogService auditLogService) {
        this.text2SqlService = text2SqlService;
        this.sqlSecurityEngine = sqlSecurityEngine;
        this.safeSqlQueryService = safeSqlQueryService;
        this.chatPendingRepository = chatPendingRepository;
        this.auditLogService = auditLogService;
    }

    public ChatAskResponse ask(String dbName, String question, String operator, String clientIp) {
        String requestId = UUID.randomUUID().toString();
        String normalizedDb = dbName.trim().toLowerCase();
        String op = defaultOperator(operator);

        try {
            Text2SqlResponse generated = text2SqlService.generate(normalizedDb, question);
            String sql = generated.sql() == null ? "" : generated.sql().trim();

            sqlSecurityEngine.validate(sql);

            ChatPendingRequest pending = ChatPendingRequest.builder()
                    .requestId(requestId)
                    .dbName(normalizedDb)
                    .question(question.trim())
                    .generatedSql(sql)
                    .reasoning(generated.reasoning())
                    .status(ChatPendingStatus.PENDING_REVIEW)
                    .operator(op)
                    .securityPassed(true)
                    .build();
            chatPendingRepository.insert(pending);

            auditLogService.recordAsk(
                    requestId,
                    normalizedDb,
                    op,
                    question.trim(),
                    sql,
                    generated.reasoning(),
                    ChatPendingStatus.PENDING_REVIEW.name(),
                    true,
                    null,
                    clientIp);

            return new ChatAskResponse(
                    requestId,
                    normalizedDb,
                    question.trim(),
                    sql,
                    generated.reasoning(),
                    ChatPendingStatus.PENDING_REVIEW.name(),
                    true,
                    "SQL 已通过安全预校验，请人工确认后调用 /api/chat/execute 执行");
        } catch (SqlSecurityException ex) {
            auditLogService.recordSecurityReject(
                    requestId, normalizedDb, op, question.trim(), null, ex.getMessage(), clientIp);
            auditLogService.recordAsk(
                    requestId,
                    normalizedDb,
                    op,
                    question.trim(),
                    null,
                    null,
                    ChatPendingStatus.REJECTED.name(),
                    false,
                    ex.getMessage(),
                    clientIp);
            throw ex;
        } catch (RuntimeException ex) {
            auditLogService.recordAsk(
                    requestId,
                    normalizedDb,
                    op,
                    question.trim(),
                    null,
                    null,
                    ChatPendingStatus.REJECTED.name(),
                    false,
                    ex.getMessage(),
                    clientIp);
            throw ex;
        }
    }

    public ChatExecuteResponse execute(
            String requestId,
            String dbName,
            String sql,
            String operator,
            String clientIp) {
        String normalizedDb = dbName.trim().toLowerCase();
        String op = defaultOperator(operator);
        String effectiveRequestId = StringUtils.hasText(requestId) ? requestId : UUID.randomUUID().toString();
        String normalizedSql = sql.trim();

        if (StringUtils.hasText(requestId)) {
            chatPendingRepository.findByRequestId(requestId).ifPresent(pending -> {
                if (!pending.getDbName().equalsIgnoreCase(normalizedDb)) {
                    throw new IllegalArgumentException("requestId 对应的数据源与请求 dbName 不一致");
                }
                if (pending.getStatus() == ChatPendingStatus.EXECUTED) {
                    throw new IllegalStateException("该请求已执行，请重新发起提问");
                }
            });
        }

        long start = System.currentTimeMillis();
        try {
            sqlSecurityEngine.validate(normalizedSql);
            List<Map<String, Object>> rows = safeSqlQueryService.query(normalizedDb, normalizedSql);
            long elapsed = System.currentTimeMillis() - start;
            List<String> columns = extractColumns(rows);

            if (StringUtils.hasText(requestId)) {
                chatPendingRepository.updateStatus(requestId, ChatPendingStatus.EXECUTED);
            }

            auditLogService.recordExecute(
                    effectiveRequestId,
                    normalizedDb,
                    op,
                    normalizedSql,
                    ChatPendingStatus.EXECUTED.name(),
                    rows.size(),
                    true,
                    null,
                    clientIp);

            return new ChatExecuteResponse(
                    effectiveRequestId,
                    normalizedDb,
                    normalizedSql,
                    columns,
                    rows,
                    rows.size(),
                    elapsed,
                    "查询执行成功");
        } catch (SqlSecurityException ex) {
            auditLogService.recordSecurityReject(
                    effectiveRequestId,
                    normalizedDb,
                    op,
                    null,
                    normalizedSql,
                    ex.getMessage(),
                    clientIp);
            auditLogService.recordExecute(
                    effectiveRequestId,
                    normalizedDb,
                    op,
                    normalizedSql,
                    ChatPendingStatus.REJECTED.name(),
                    0,
                    false,
                    ex.getMessage(),
                    clientIp);
            throw ex;
        } catch (RuntimeException ex) {
            auditLogService.recordExecute(
                    effectiveRequestId,
                    normalizedDb,
                    op,
                    normalizedSql,
                    ChatPendingStatus.REJECTED.name(),
                    0,
                    false,
                    ex.getMessage(),
                    clientIp);
            throw ex;
        }
    }

    private static List<String> extractColumns(List<Map<String, Object>> rows) {
        if (rows.isEmpty()) {
            return List.of();
        }
        Set<String> columns = new LinkedHashSet<>(rows.get(0).keySet());
        return new ArrayList<>(columns);
    }

    private static String defaultOperator(String operator) {
        return StringUtils.hasText(operator) ? operator.trim() : "anonymous";
    }
}
