package com.example.text2sql.domain;

import lombok.Builder;
import lombok.Value;

import java.time.LocalDateTime;

/**
 * 审计日志实体，对应表 t_audit_log。
 */
@Value
@Builder
public class AuditLog {
    Long id;
    String requestId;
    AuditActionType actionType;
    String dbName;
    String operator;
    String question;
    String generatedSql;
    String executedSql;
    String reasoning;
    String status;
    Integer resultRowCount;
    boolean success;
    String errorMessage;
    String clientIp;
    LocalDateTime createdAt;
}
