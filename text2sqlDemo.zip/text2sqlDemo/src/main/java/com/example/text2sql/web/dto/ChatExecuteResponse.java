package com.example.text2sql.web.dto;

import java.util.List;
import java.util.Map;

public record ChatExecuteResponse(
        String requestId,
        String dbName,
        String sql,
        List<String> columns,
        List<Map<String, Object>> rows,
        int rowCount,
        long executionTimeMs,
        String message) {
}
