package com.example.text2sql.metadata;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ColumnSchema {
    String columnName;
    String dataType;
    boolean nullable;
    String columnKey;
    String comment;
    int ordinalPosition;
}
