package com.example.text2sql.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class DynamicJdbcServiceTest {

    @Autowired
    private DynamicJdbcService dynamicJdbcService;

    @Test
    void loadsDataFromBothH2DataSources() {
        assertThat(dynamicJdbcService.getDatabaseType("customer")).isEqualTo("H2");
        assertThat(dynamicJdbcService.getDatabaseType("order")).isEqualTo("H2");

        Integer customerCount = dynamicJdbcService.getJdbcTemplate("customer")
                .queryForObject("SELECT COUNT(*) FROM t_customer", Integer.class);
        Integer orderCount = dynamicJdbcService.getJdbcTemplate("order")
                .queryForObject("SELECT COUNT(*) FROM t_order", Integer.class);

        assertThat(customerCount).isEqualTo(3);
        assertThat(orderCount).isEqualTo(4);
    }
}
