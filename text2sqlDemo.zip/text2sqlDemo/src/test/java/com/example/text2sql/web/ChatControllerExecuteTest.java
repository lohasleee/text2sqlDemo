package com.example.text2sql.web;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ChatControllerExecuteTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void executeReturnsTableData() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-Operator-Id", "tester");

        HttpEntity<String> entity = new HttpEntity<>(
                """
                        {
                          "dbName": "customer",
                          "sql": "SELECT customer_name, level FROM t_customer WHERE level = 'VIP'"
                        }
                        """,
                headers);

        ResponseEntity<Map> response = restTemplate.postForEntity("/api/chat/execute", entity, Map.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().get("rowCount")).isEqualTo(1);
    }

    @Test
    void executeRejectsUnsafeSql() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(
                """
                        {
                          "dbName": "customer",
                          "sql": "DELETE FROM t_customer"
                        }
                        """,
                headers);

        ResponseEntity<String> response = restTemplate.postForEntity("/api/chat/execute", entity, String.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }
}
