package com.example.text2sql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Text2sqlDemoApplicationTests {

    @Test
    void contextLoads() {
    }
}
