package com.example.text2sql.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SqlSecurityEngineTest {

    private SqlSecurityEngine engine;

    @BeforeEach
    void setUp() {
        engine = new SqlSecurityEngine();
    }

    @Test
    void allowsSimpleSelect() {
        assertThatCode(() -> engine.validate("SELECT id, customer_name FROM t_customer WHERE level = 'VIP'"))
                .doesNotThrowAnyException();
    }

    @Test
    void allowsSelectWithTrailingSemicolon() {
        assertThatCode(() -> engine.validate("SELECT COUNT(*) FROM t_order;"))
                .doesNotThrowAnyException();
    }

    @Test
    void rejectsInsert() {
        assertThatThrownBy(() -> engine.validate("INSERT INTO t_customer VALUES (1, 'x')"))
                .isInstanceOf(SqlSecurityException.class)
                .hasMessageContaining("SELECT");
    }

    @Test
    void rejectsUpdateDeleteDrop() {
        assertThatThrownBy(() -> engine.validate("UPDATE t_customer SET phone = '1'"))
                .isInstanceOf(SqlSecurityException.class);
        assertThatThrownBy(() -> engine.validate("DELETE FROM t_customer"))
                .isInstanceOf(SqlSecurityException.class);
        assertThatThrownBy(() -> engine.validate("DROP TABLE t_customer"))
                .isInstanceOf(SqlSecurityException.class);
    }

    @Test
    void rejectsMultiStatement() {
        assertThatThrownBy(() -> engine.validate("SELECT 1; SELECT 2"))
                .isInstanceOf(SqlSecurityException.class)
                .hasMessageContaining("多语句");
    }

    @Test
    void rejectsSleepAndBenchmark() {
        assertThatThrownBy(() -> engine.validate("SELECT SLEEP(5)"))
                .isInstanceOf(SqlSecurityException.class);
        assertThatThrownBy(() -> engine.validate("SELECT BENCHMARK(1000000, MD5('x'))"))
                .isInstanceOf(SqlSecurityException.class);
    }

    @Test
    void allowsColumnNamesContainingKeywordFragments() {
        assertThatCode(() -> engine.validate(
                "SELECT create_time, updated_flag FROM t_customer"))
                .doesNotThrowAnyException();
    }
}
