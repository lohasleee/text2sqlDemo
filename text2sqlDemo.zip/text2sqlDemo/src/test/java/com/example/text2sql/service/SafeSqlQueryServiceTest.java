package com.example.text2sql.service;

import com.example.text2sql.security.SqlSecurityException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
class SafeSqlQueryServiceTest {

    @Autowired
    private SafeSqlQueryService safeSqlQueryService;

    @Test
    void executesValidatedSelectOnH2() {
        var rows = safeSqlQueryService.query("customer",
                "SELECT customer_name, level FROM t_customer WHERE level = 'VIP'");
        assertThat(rows).hasSize(1);
        assertThat(rows.get(0).values()).contains("VIP");
        assertThat(rows.get(0).values()).contains("张三");
        assertThat(rows.get(0)).hasSize(2);
    }

    @Test
    void rejectsUnsafeSqlBeforeExecution() {
        assertThatThrownBy(() -> safeSqlQueryService.query("customer", "DELETE FROM t_customer"))
                .isInstanceOf(SqlSecurityException.class);
    }
}
