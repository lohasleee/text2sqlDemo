package com.example.text2sql.service;

import com.example.text2sql.metadata.DatabaseSchemaDescription;
import com.example.text2sql.metadata.TableSchema;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.StringUtils;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class MetadataServiceTest {

    @Autowired
    private MetadataService metadataService;

    @Test
    void loadsCustomerSchemaWithComments() {
        DatabaseSchemaDescription schema = metadataService.loadSchema("customer");
        assertThat(schema.getDatabaseType()).isEqualTo("H2");
        assertThat(schema.getTables()).extracting(TableSchema::getTableName)
                .contains("t_customer");
        assertThat(schema.getTables().get(0).getColumns()).isNotEmpty();
        assertThat(schema.getTables().get(0).getColumns())
                .anyMatch(c -> "customer_name".equals(c.getColumnName())
                        && StringUtils.hasText(c.getComment()));

        String json = metadataService.toStructuredJson(schema);
        assertThat(json).contains("t_customer").contains("customer_name");

        String prompt = metadataService.toPromptText(schema);
        assertThat(prompt).contains("方言: H2").contains("H2 说明");
    }

    @Test
    void loadsOrderSchema() {
        DatabaseSchemaDescription schema = metadataService.loadSchema("order");
        assertThat(schema.getTables()).extracting(TableSchema::getTableName)
                .contains("t_order");
    }
}
