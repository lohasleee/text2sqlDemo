USE audit_db;

DROP TABLE IF EXISTS t_audit_log;
DROP TABLE IF EXISTS t_chat_pending;

CREATE TABLE t_chat_pending (
    id              BIGINT          NOT NULL AUTO_INCREMENT COMMENT '主键',
    request_id      VARCHAR(36)     NOT NULL COMMENT '请求 UUID，对外暴露',
    db_name         VARCHAR(32)     NOT NULL COMMENT '目标业务库：customer / order',
    question        VARCHAR(2000)   NOT NULL COMMENT '用户自然语言问题',
    generated_sql   VARCHAR(4000)   DEFAULT NULL COMMENT '模型生成的 SQL',
    reasoning       VARCHAR(4000)   DEFAULT NULL COMMENT '模型生成思路',
    status          VARCHAR(32)     NOT NULL COMMENT 'PENDING_REVIEW / EXECUTED / REJECTED',
    operator        VARCHAR(64)     DEFAULT NULL COMMENT '提问人',
    security_passed TINYINT         NOT NULL DEFAULT 0 COMMENT '预校验是否通过：0-否，1-是',
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE (request_id)
) COMMENT='Text2SQL 待人工确认上下文';

CREATE TABLE t_audit_log (
    id                  BIGINT          NOT NULL AUTO_INCREMENT COMMENT '主键',
    request_id          VARCHAR(36)     DEFAULT NULL COMMENT '关联请求 UUID',
    action_type         VARCHAR(32)     NOT NULL COMMENT 'ASK / EXECUTE / SECURITY_REJECT',
    db_name             VARCHAR(32)     DEFAULT NULL COMMENT '业务库标识',
    operator            VARCHAR(64)     DEFAULT NULL COMMENT '操作人',
    question            VARCHAR(2000)   DEFAULT NULL COMMENT '用户问题',
    generated_sql       VARCHAR(4000)   DEFAULT NULL COMMENT '生成的 SQL',
    executed_sql        VARCHAR(4000)   DEFAULT NULL COMMENT '最终执行的 SQL',
    reasoning           VARCHAR(4000)   DEFAULT NULL COMMENT '生成思路',
    status              VARCHAR(32)     DEFAULT NULL COMMENT '业务状态快照',
    result_row_count    INT             DEFAULT NULL COMMENT '结果行数',
    success             TINYINT         NOT NULL DEFAULT 1 COMMENT '是否成功：0-否，1-是',
    error_message       VARCHAR(2000)   DEFAULT NULL COMMENT '失败原因',
    client_ip           VARCHAR(64)     DEFAULT NULL COMMENT '客户端 IP',
    created_at          TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
    PRIMARY KEY (id),
    KEY idx_audit_request_id (request_id),
    KEY idx_audit_created_at (created_at)
) COMMENT='Text2SQL 审计日志';
