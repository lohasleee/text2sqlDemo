USE order_db;

DROP TABLE IF EXISTS t_order;

CREATE TABLE t_order (
    id              BIGINT          NOT NULL AUTO_INCREMENT COMMENT '订单主键 ID',
    order_no        VARCHAR(32)     NOT NULL COMMENT '订单编号，业务唯一',
    customer_id     BIGINT          NOT NULL COMMENT '客户 ID（逻辑关联客户库 t_customer.id，跨库无外键）',
    amount          DECIMAL(12, 2)  NOT NULL DEFAULT 0.00 COMMENT '订单金额（元）',
    status          TINYINT         NOT NULL DEFAULT 0 COMMENT '订单状态：0-待支付，1-已支付，2-已完成，3-已取消',
    order_date      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '下单时间',
    PRIMARY KEY (id),
    UNIQUE (order_no)
) COMMENT='订单表（订单系统库）';

INSERT INTO t_order (order_no, customer_id, amount, status, order_date) VALUES
    ('ORD20260301001', 1, 5999.00, 2, '2026-03-01 10:05:00'),
    ('ORD20260302001', 1, 198.00, 2, '2026-03-02 11:20:00'),
    ('ORD20260305001', 2, 459.00, 1, '2026-03-05 09:00:00'),
    ('ORD20260310001', 3, 12800.00, 0, '2026-03-10 16:45:00');
