@echo off
setlocal EnableExtensions

rem 优先读取 local-java.home（一行，JDK 根目录），便于本机覆盖
if exist "%~dp0local-java.home" (
  set /p _JAVA_HOME=<"%~dp0local-java.home"
  if defined _JAVA_HOME set "JAVA_HOME=%_JAVA_HOME%"
)

if not defined JAVA_HOME set "JAVA_HOME=D:\fdeEnv\jdk17"

if not exist "%JAVA_HOME%\bin\java.exe" (
  echo [ERROR] 未找到 JDK 17：%JAVA_HOME%
  echo 请安装 JDK 17，或创建 local-java.home 写入 JDK 路径，或设置环境变量 JAVA_HOME。
  exit /b 1
)

set "PATH=%JAVA_HOME%\bin;%PATH%"
set "MAVEN_OPTS=-Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8"
set "JAVA_TOOL_OPTIONS=-Dfile.encoding=UTF-8"
echo Using JAVA_HOME=%JAVA_HOME%
"%JAVA_HOME%\bin\java.exe" -version
call mvn %*
