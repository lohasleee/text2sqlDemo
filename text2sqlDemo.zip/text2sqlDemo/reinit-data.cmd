@echo off
echo 删除 H2 数据文件并将在下次启动时用 UTF-8 重新导入中文测试数据...
if exist "%~dp0data" rd /s /q "%~dp0data"
echo 完成。请执行: mvn-jdk17.cmd spring-boot:run
