# Text2SQL Demo

面向企业内「自然语言查数」场景的 **Spring Boot 3 + Spring AI** 参考实现：多数据源元数据驱动 Text2SQL、静态 SQL 安全闸、人机协同执行与全链路审计。默认 **Stub 生成器** 可在无 LLM 环境下完整跑通；Docker 一键拉起 **MySQL 8 + 应用**，并自动执行 `init-test-db.sql` 等初始化脚本。

| 技术栈 | 版本 / 说明 |
|--------|-------------|
| Java | 17 |
| Spring Boot | 3.3.5 |
| Spring AI | 1.0.0（Ollama / OpenAI 可选） |
| 本地开发 DB | H2 文件库（`./data`） |
| 容器化 DB | MySQL 8.0（`docker` Profile） |

---

## 项目亮点

1. **多数据源 Text2SQL** — `customer_db` / `order_db` 独立 JDBC 与元数据 introspection（MySQL `information_schema` + H2 `DatabaseMetaData`），生成 SQL 时注入真实表结构、主键与 COMMENT，降低「幻觉表名/字段」风险。
2. **可插拔 LLM** — `app.text2sql.provider=stub|ai`：Stub 用于演示与 CI；`ai` 走 Spring AI（Ollama 本地或 OpenAI），结构化输出 `sql` + `reasoning`。
3. **双层安全** — `SqlSecurityEngine` 静态规则（仅 SELECT、禁多语句/危险关键字/函数/UNION 注入等）+ `ReadOnlyDataSource` / `SafeSqlQueryService` 只读执行通道。
4. **人机协同（Human-in-the-loop）** — `/api/chat/ask` 只生成并预检 SQL，状态 `PENDING_REVIEW`；用户确认后 `/api/chat/execute` 才落库查询，避免「模型一句话直接跑库」。
5. **审计闭环** — 独立 `audit_db`：`t_chat_pending`、`t_audit_log`，记录操作人、客户端 IP、安全通过与拒绝原因，满足内控与事后追溯。
6. **开箱 UI** — 静态页 `index.html`（Tailwind + Alpine.js）：提问 → 审阅 SQL → 执行 → 表格展示结果。
7. **环境一致** — `application-docker.yml` 与 Compose 对齐；MySQL 首次启动自动挂载 `docker/mysql-init/*` 与 **`src/main/resources/db/init-test-db.sql`**（单库宽表示例 + 中文注释）。

---

## 业务痛点与方案映射

| 痛点 | 本项目的应对 |
|------|----------------|
| 业务人员不会写 SQL，但又要自助查数 | 自然语言 → Text2SQL，UI + REST 双入口 |
| 大模型 SQL 可能删改数据或拖垮库 | 仅 SELECT + 静态规则；执行层只读数据源 |
| 模型幻觉导致查错表、错库 | 按 `dbName` 路由数据源，Prompt 内嵌实时 Schema |
| 跨库（客户 / 订单）口径不一致 | 显式多数据源配置，禁止隐式跨库 JOIN（由路由边界约束） |
| 合规要求「谁、何时、问了什么、跑了什么 SQL」 | 审计库 + 待审队列 + HTTP 拦截器写日志 |
| 开发 / 演示 / 生产库类型不一致 | 本地 H2、Docker MySQL 同一套业务代码，Profile 切换 |

---

## 架构与核心流程

### 逻辑架构

```mermaid
flowchart TB
  subgraph Client
    UI[静态 UI /index.html]
    API[REST Client]
  end

  subgraph App["Spring Boot App"]
    CC[ChatController]
    CAS[ChatApplicationService]
    T2S[Text2SqlService]
    META[MetadataService]
    SEC[SqlSecurityEngine]
    SAFE[SafeSqlQueryService]
    AUD[AuditLogService]
  end

  subgraph LLM["可选 LLM"]
    STUB[StubText2SqlGenerator]
    AI[Spring AI Ollama/OpenAI]
  end

  subgraph Data
    CDB[(customer_db)]
    ODB[(order_db)]
    ADB[(audit_db)]
  end

  UI --> CC
  API --> CC
  CC --> CAS
  CAS --> T2S
  T2S --> STUB
  T2S --> AI
  T2S --> META
  META --> CDB
  META --> ODB
  CAS --> SEC
  CAS --> SAFE
  SAFE --> CDB
  SAFE --> ODB
  CAS --> AUD
  AUD --> ADB
```

### 问答与执行时序

```mermaid
sequenceDiagram
  participant U as 用户
  participant C as ChatController
  participant S as ChatApplicationService
  participant T as Text2SqlService
  participant E as SqlSecurityEngine
  participant P as t_chat_pending
  participant Q as SafeSqlQueryService
  participant L as t_audit_log

  U->>C: POST /api/chat/ask { dbName, question }
  C->>S: ask(...)
  S->>T: generate(db, question)
  T-->>S: sql + reasoning
  S->>E: validate(sql)
  alt 通过
    S->>P: INSERT PENDING_REVIEW
    S->>L: recordAsk
    S-->>U: requestId + SQL 待确认
  else 拒绝
    S->>L: recordSecurityReject
    S-->>U: REJECTED + 原因
  end

  U->>C: POST /api/chat/execute { requestId }
  C->>S: execute(...)
  S->>P: 校验状态
  S->>E: validate(sql) 再次校验
  S->>Q: queryReadOnly(db, sql)
  Q-->>S: 结果集
  S->>L: recordExecute
  S-->>U: 行数据 + 列名
```

### Docker 部署拓扑

```mermaid
flowchart LR
  subgraph Host
    DC[docker compose]
  end
  subgraph Network
    MY[(mysql:3306)]
    APP[app:8080]
  end
  DC --> MY
  DC --> APP
  APP -->|JDBC customer/order/audit| MY
  MY -->|/docker-entrypoint-initdb.d| INIT[01~04 mysql-init + 05 init-test-db.sql]
```

---

## 安全边界说明

> 本仓库为 **演示 / PoC** 级别实现，上线生产前需叠加网络隔离、身份认证、行级权限与 SQL 解析器（如 JSqlParser）等能力。

| 层级 | 机制 | 边界 |
|------|------|------|
| 生成 | Text2SqlService + Schema Prompt | 不保证语义 100% 正确；依赖人工审阅 |
| 静态校验 | `SqlSecurityEngine` | 正则/关键字级防护，**不能**替代完整 SQL 语法白名单 |
| 执行 | `SafeSqlQueryService` + 只读包装 | 仅对已通过校验的 SELECT 下发 JDBC |
| 流程 | `PENDING_REVIEW` | 默认禁止 ask 接口直接返回可执行结果集 |
| 审计 | `audit_db` | 记录 ask / execute / 安全拒绝；**不**替代 SIEM |
| 认证 | 当前 Demo | **无**登录态；`operator` 由请求头/参数传入，需在生产接入 SSO |
| 密钥 | OpenAI / DB 密码 | 通过环境变量注入，**勿**提交仓库 |

**明确不在范围内：** 跨租户行级授权、敏感字段脱敏、查询成本配额（超时/行数上限仅部分约束）、WAF 与 API 限流。

---

## 快速启动（Docker 一键运行）

### 前置条件

- Docker Engine 20.10+ 与 Docker Compose V2
- 本机 **8080**、**3306** 端口未被占用（可通过环境变量改映射）

### 启动

```bash
cd text2sqlDemo
docker compose up --build -d
```

首次启动 MySQL 会执行：

- `docker/mysql-init/01-create-databases.sql` … `04-init-audit.sql`（业务库 + 审计库）
- **`src/main/resources/db/init-test-db.sql`** → 容器内 `05-init-test-db.sql`（`text2sql_demo` 单库样例）

### 访问

| 入口 | URL |
|------|-----|
| Web UI | http://localhost:8080/ |
| 提问 API | `POST http://localhost:8080/api/chat/ask` |
| 执行 API | `POST http://localhost:8080/api/chat/execute` |

示例（Stub 模式，无需 Ollama）：

```bash
curl -s -X POST http://localhost:8080/api/chat/ask \
  -H "Content-Type: application/json" \
  -d "{\"dbName\":\"customer\",\"question\":\"查询所有客户姓名\"}"
```

### 常用环境变量

| 变量 | 默认 | 说明 |
|------|------|------|
| `MYSQL_ROOT_PASSWORD` | `text2sql_root` | MySQL root 密码（App 同步使用） |
| `APP_PORT` | `8080` | 应用宿主机端口 |
| `MYSQL_PORT` | `3306` | MySQL 宿主机端口 |
| `TEXT2SQL_PROVIDER` | `stub` | 设为 `ai` 并配置 Ollama/OpenAI |
| `OLLAMA_BASE_URL` | `http://host.docker.internal:11434` | 容器内访问宿主机 Ollama |

启用 AI（宿主机已运行 Ollama）：

```bash
TEXT2SQL_PROVIDER=ai docker compose up --build -d
```

### 停止与清理

```bash
docker compose down          # 保留 mysql_data 卷
docker compose down -v       # 删除数据卷，下次重新 init SQL
```

### 健康检查

- **mysql**：`mysqladmin ping`
- **app**：`GET /`（静态首页）；镜像内已安装 `curl`

---

## 本地开发（H2，非 Docker）

需 **JDK 17**（Windows 可用项目根目录 `mvn-jdk17.cmd`）：

```bash
mvn-jdk17.cmd spring-boot:run
```

- 数据文件：`./data/`（若中文乱码，删除 `data` 后执行 `reinit-data.cmd` 或手动重启）
- H2 Console：http://localhost:8080/h2-console
- 默认 Text2SQL：`app.text2sql.provider=stub`（见 `application.yml`）

---

## 目录速览

```
├── Dockerfile                          # 多阶段构建 Spring Boot JAR
├── docker-compose.yml                  # MySQL + App
├── docker/mysql-init/                  # MySQL 首次初始化（多库）
├── src/main/resources/
│   ├── application.yml                 # 默认 / H2
│   ├── application-docker.yml          # Compose / MySQL
│   ├── db/init-test-db.sql             # 单库演示（Compose 自动挂载）
│   └── static/index.html               # 前端
└── src/main/java/.../                  # 配置、安全、服务、API
```

---

## 构建与测试

```bash
mvn -DskipTests package          # 需 JDK 17
mvn test                         # SqlSecurityEngine / SafeSqlQueryService 等
```

---

## 许可证与声明

示例代码仅供学习与内部分享；生产使用前请完成安全评估、渗透测试与合规评审。
